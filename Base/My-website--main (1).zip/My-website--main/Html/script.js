const $ = sel => document.querySelector(sel);

async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function loadStats() {
  try {
    const data = await fetchJson('/api/stats');
    $('#guildName').textContent = data.name || 'Discord Server';
    $('#memberCount').textContent = data.approximate_member_count ?? '—';
    $('#onlineCount').textContent = data.approximate_presence_count ?? '—';
    $('#boostCount').textContent = data.premium_subscription_count ?? '—';
    // load channels and roles too
    loadChannels();
    loadRoles();
    $('#statsUpdated').textContent = new Date().toLocaleTimeString();
    updateStatus(true, data.mock ? 'mock' : 'connected');
  } catch (err) {
    console.error('loadStats', err);
    $('#memberCount').textContent = 'error';
    $('#statsUpdated').textContent = 'error';
    updateStatus(false, err.message || 'error');
  }
}

function formatDate(iso) {
  try {
    const tz = document.querySelector('#tzSelect')?.value || 'local';
    const d = new Date(iso);
    if (tz === 'utc') return d.toUTCString();
    return d.toLocaleString();
  } catch { return iso; }
}

async function loadChannels(){
  try {
    const data = await fetchJson('/api/channels');
    $('#channelCount').textContent = data.total ?? '—';
  } catch (err) {
    console.error('loadChannels', err);
    $('#channelCount').textContent = 'error';
  }
}

async function loadRoles(){
  try {
    const data = await fetchJson('/api/roles');
    $('#roleCount').textContent = data.total ?? '—';
  } catch (err) {
    console.error('loadRoles', err);
    $('#roleCount').textContent = 'error';
  }
}

async function loadEvents() {
  try {
    const data = await fetchJson('/api/events');
    const list = $('#eventsList');
    list.innerHTML = '';
    const events = data.events || [];
    if (!events.length) {
      list.innerHTML = '<li class="empty">No upcoming events</li>';
    } else {
      events.forEach(e => {
        const li = document.createElement('li');
        li.className = 'event';
        li.innerHTML = `
          <div class="eventTitle">${escapeHtml(e.name)}</div>
          <div class="eventTime">${formatDate(e.scheduled_start_time)}</div>
          <div class="eventMeta">${e.user_count ?? ''} attending · status ${e.status}</div>
          <div class="eventCountdown" data-start="${e.scheduled_start_time}"></div>
        `;
        list.appendChild(li);
      });
      // start countdown timers
      startCountdowns();
    }
    $('#eventsUpdated').textContent = new Date().toLocaleTimeString();
  } catch (err) {
    console.error('loadEvents', err);
    $('#eventsList').innerHTML = '<li class="empty">Error loading events</li>';
    $('#eventsUpdated').textContent = 'error';
    updateStatus(false, err.message || 'error');
  }
}

// Modal handling: event details
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalBody = document.getElementById('modalBody');
const modalClose = document.getElementById('modalClose');
document.getElementById('eventsList').addEventListener('click', e => {
  const li = e.target.closest('.event');
  if (!li) return;
  const title = li.querySelector('.eventTitle')?.textContent || '';
  const time = li.querySelector('.eventTime')?.textContent || '';
  const meta = li.querySelector('.eventMeta')?.textContent || '';
  modalTitle.textContent = title;
  modalBody.innerHTML = `<p><strong>${escapeHtml(time)}</strong></p><p>${escapeHtml(meta)}</p>`;
  modal.setAttribute('aria-hidden', 'false');
  modal.style.display = 'block';
});
modalClose.addEventListener('click', () => { modal.style.display = 'none'; modal.setAttribute('aria-hidden','true'); });

document.querySelector('#tzSelect')?.addEventListener('change', () => { loadEvents(); });

function updateStatus(ok, msg) {
  const badge = $('#statusBadge');
  if (!badge) return;
  if (ok) {
    badge.textContent = msg === 'mock' ? 'Mock data' : 'Connected';
    badge.className = 'ok';
  } else {
    badge.textContent = 'Error';
    badge.className = 'err';
  }
}

function startCountdowns(){
  const els = document.querySelectorAll('.eventCountdown');
  function tick(){
    els.forEach(el => {
      const start = el.dataset.start;
      if(!start) return;
      const d = new Date(start) - new Date();
      if (isNaN(d)) { el.textContent = ''; return; }
      if (d <= 0) { el.textContent = 'Started'; return; }
      const days = Math.floor(d / (24*60*60*1000));
      const hours = Math.floor((d % (24*60*60*1000)) / (60*60*1000));
      const mins = Math.floor((d % (60*60*1000)) / (60*1000));
      const secs = Math.floor((d % (60*1000)) / 1000);
      el.textContent = `${days?days+'d ':''}${String(hours).padStart(2,'0')}h ${String(mins).padStart(2,'0')}m ${String(secs).padStart(2,'0')}s`;
    });
  }
  tick();
  clearInterval(window._eventCountdownInterval);
  window._eventCountdownInterval = setInterval(tick, 1000);
}

function escapeHtml(s){
  if(!s) return '';
  return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
}

async function refreshAll(){
  await Promise.all([loadStats(), loadEvents()]);
}

// Initial load
refreshAll();

// Polling: stats every 20s, events every 60s
setInterval(loadStats, 20_000);
setInterval(loadEvents, 60_000);
