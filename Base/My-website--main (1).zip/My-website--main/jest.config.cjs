module.exports = {
  testEnvironment: 'node'
};
