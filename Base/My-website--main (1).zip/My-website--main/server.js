import express from 'express';
import fetch from 'node-fetch';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import {fileURLToPath} from 'url';
import Redis from 'ioredis';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const DISCORD_TOKEN = process.env.DISCORD_BOT_TOKEN;
const GUILD_ID = process.env.GUILD_ID;

function tokenLooksValid(token) {
  if (!token) return false;
  // Basic heuristic: Discord bot tokens often contain two dots (three parts)
  try {
    const parts = token.split('.');
    return parts.length >= 3 && token.length > 20;
  } catch {
    return false;
  }
}

if (!DISCORD_TOKEN || !GUILD_ID) {
  console.warn('Warning: set DISCORD_BOT_TOKEN and GUILD_ID environment variables. The server will still run but API endpoints will return errors until these are provided.');
} else {
  if (DISCORD_TOKEN.startsWith('Bot ')) {
    console.warn('Warning: DISCORD_BOT_TOKEN in .env appears to include the "Bot " prefix. Remove the prefix so the value is the raw token string.');
  }
  if (!tokenLooksValid(DISCORD_TOKEN)) {
    console.warn('Warning: DISCORD_BOT_TOKEN does not match expected shape. API calls may fail with 401 Unauthorized.');
  }
}

// NOTE: mock/fallback mode removed. Provide a valid DISCORD_BOT_TOKEN and GUILD_ID to fetch real data from Discord.

const app = express();
app.use(cors());
app.use(express.json());

// Serve the static frontend
app.use(express.static(path.join(__dirname, 'Html')));

// Simple in-memory cache to reduce Discord API calls; optional Redis if REDIS_URL provided
const cache = {
  stats: { ts: 0, data: null },
  events: { ts: 0, data: null }
};
const CACHE_TTL = parseInt(process.env.CACHE_TTL_MS || String(30 * 1000), 10); // default 30s
const REDIS_URL = process.env.REDIS_URL || null;
let redis = null;
if (REDIS_URL) {
  try {
    redis = new Redis(REDIS_URL);
    console.log('Connected to Redis');
  } catch (e) {
    console.warn('Failed to connect to Redis, falling back to in-memory cache', e.message || e);
    redis = null;
  }
}

async function cacheGet(key) {
  if (redis) {
    const v = await redis.get(key).catch(() => null);
    return v ? JSON.parse(v) : null;
  }
  const entry = cache[key];
  if (entry && Date.now() - entry.ts < CACHE_TTL) return entry.data;
  return null;
}

async function cacheSet(key, data, ttl = CACHE_TTL) {
  if (redis) {
    await redis.set(key, JSON.stringify(data), 'PX', ttl).catch(() => {});
    return;
  }
  cache[key] = { ts: Date.now(), data };
}

async function discordFetch(endpoint) {
  const url = `https://discord.com/api/v10${endpoint}`;
  const res = await fetch(url, {
    headers: {
      Authorization: `Bot ${DISCORD_TOKEN}`,
      Accept: 'application/json'
    }
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const err = new Error(`Discord API ${res.status} ${res.statusText}: ${text}`);
    err.status = res.status;
    throw err;
  }
  return res.json();
}

app.get('/api/stats', async (req, res) => {
  try {
    const cacheKey = `stats:${GUILD_ID}`;
    const cached = await cacheGet(cacheKey);
    if (cached) return res.json({ fromCache: true, ...cached });

    if (!DISCORD_TOKEN || !GUILD_ID) {
      return res.status(400).json({ error: 'DISCORD_BOT_TOKEN and GUILD_ID must be set on the server.' });
    }

    // with_counts=true provides approximate_member_count and approximate_presence_count
    const guild = await discordFetch(`/guilds/${GUILD_ID}?with_counts=true`);

    const data = {
      id: guild.id,
      name: guild.name,
      approximate_member_count: guild.approximate_member_count ?? null,
      approximate_presence_count: guild.approximate_presence_count ?? null,
      premium_subscription_count: guild.premium_subscription_count ?? null,
      description: guild.description ?? null
    };

    await cacheSet(cacheKey, data);
    res.json({ fromCache: false, ...data });
  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.get('/api/events', async (req, res) => {
  try {
    // No mock mode: proceed to fetch real events from Discord
    const cacheKey = `events:${GUILD_ID}`;
    const cached = await cacheGet(cacheKey);
    if (cached) return res.json({ fromCache: true, events: cached });

    if (!DISCORD_TOKEN || !GUILD_ID) {
      return res.status(400).json({ error: 'DISCORD_BOT_TOKEN and GUILD_ID must be set on the server.' });
    }

    // Fetch scheduled events (with_user_count is optional)
    const events = await discordFetch(`/guilds/${GUILD_ID}/scheduled-events?with_user_count=true`);

    // Map to a simple shape and filter upcoming (status 1 = SCHEDULED) or future times
    const nowISO = new Date().toISOString();
    const mapped = (events || []).map(e => ({
      id: e.id,
      name: e.name,
      description: e.description ?? null,
      scheduled_start_time: e.scheduled_start_time,
      scheduled_end_time: e.scheduled_end_time ?? null,
      status: e.status, // 1 = SCHEDULED, 2 = ACTIVE, 3 = COMPLETED, 4 = CANCELED
      user_count: e.user_count ?? null
    }))
    .filter(e => (e.scheduled_start_time || '') >= nowISO || e.status === 2)
    .sort((a,b) => new Date(a.scheduled_start_time) - new Date(b.scheduled_start_time));

    await cacheSet(cacheKey, mapped);
    res.json({ fromCache: false, events: mapped });
  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Additional endpoints: channels and roles counts
app.get('/api/channels', async (req, res) => {
  try {
    if (!DISCORD_TOKEN || !GUILD_ID) {
      return res.status(400).json({ error: 'DISCORD_BOT_TOKEN and GUILD_ID must be set on the server.' });
    }
    const cacheKey = `channels:${GUILD_ID}`;
    const cached = await cacheGet(cacheKey);
    if (cached) return res.json({ fromCache: true, ...cached });

    const channels = await discordFetch(`/guilds/${GUILD_ID}/channels`);
    // count by type
    const byType = {};
    (channels || []).forEach(c => { byType[c.type] = (byType[c.type] || 0) + 1; });
    const data = { total: (channels || []).length, byType };
    await cacheSet(cacheKey, data);
    res.json({ fromCache: false, ...data });
  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.get('/api/roles', async (req, res) => {
  try {
    if (!DISCORD_TOKEN || !GUILD_ID) {
      return res.status(400).json({ error: 'DISCORD_BOT_TOKEN and GUILD_ID must be set on the server.' });
    }
    const cacheKey = `roles:${GUILD_ID}`;
    const cached = await cacheGet(cacheKey);
    if (cached) return res.json({ fromCache: true, ...cached });

    const roles = await discordFetch(`/guilds/${GUILD_ID}/roles`);
    const data = { total: (roles || []).length };
    await cacheSet(cacheKey, data);
    res.json({ fromCache: false, ...data });
  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Fallback to index.html for single page usage
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'Html', 'index.html'));
});

if (process.env.RUN_SERVER !== 'false') {
  app.listen(PORT, () => {
    console.log(`Server listening on http://localhost:${PORT}`);
  });
} else {
  console.log('Server not started because RUN_SERVER=false');
}

export default app;
