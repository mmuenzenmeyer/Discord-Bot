# Discord Server Stats & Events (minimal)

This small project provides:

- An Express backend that queries the Discord API (requires a bot token) and exposes two endpoints: `/api/stats` and `/api/events`.
- A simple static frontend in `Html/` that displays server stats and upcoming scheduled events.

Important: do NOT expose your bot token publicly. Keep it in environment variables on your server.

Setup
1. Copy `.env.example` to `.env` and fill in `DISCORD_BOT_TOKEN` and `GUILD_ID`.
2. Install dependencies and start the server.

Example:

```bash
cp .env.example .env
# Edit .env to add your Bot token and GUILD_ID
npm install
npm start
```

Open `http://localhost:3000` and you should see the frontend. The backend endpoints are:

- `GET /api/stats` — returns approximate_member_count, approximate_presence_count, premium_subscription_count
- `GET /api/events` — returns upcoming scheduled events

Additional endpoints
- `GET /api/channels` — returns channel counts (total and by type)
- `GET /api/roles` — returns role count

Optional Redis caching
- To enable persistent caching across instances, set `REDIS_URL` in your `.env` to a Redis connection string (e.g. `redis://:password@host:6379/0`). The server will use Redis for caching when available.

Notes
- The backend uses a short in-memory cache (30s) to reduce Discord API calls.
- You must create a Discord bot and invite it to the server with the necessary permissions to view scheduled events. Use its token as `DISCORD_BOT_TOKEN` and your server's ID as `GUILD_ID`.

Deployment / running in production

Recommended quick production options:

- pm2 (process manager)
	- Install: `sudo npm i -g pm2`
	- Start: `pm2 start ecosystem.config.js --env production`
	- Logs: `pm2 logs discord-stats`
	- Auto-start on boot: `pm2 save` then `pm2 startup`

- systemd example
	- See `examples/discord-stats.service` for a sample unit file. Copy it to `/etc/systemd/system/discord-stats.service`, edit `WorkingDirectory` and `EnvironmentFile` to match your paths, then:
		```bash
		sudo systemctl daemon-reload
		sudo systemctl enable discord-stats
		sudo systemctl start discord-stats
		sudo journalctl -u discord-stats -f
		```

- Docker
	- Build: `docker build -t discord-stats .`
	- Run: `docker run --env-file .env -p 3000:3000 discord-stats`
	- Or use `docker compose up -d --build` (provided `docker-compose.yml`).

Reverse proxy / TLS

Use nginx as a reverse proxy to forward port 80/443 to the app (port 3000). Use Certbot to obtain TLS certificates.



